#include <func.h>

int main()
{
	while(1);
}
