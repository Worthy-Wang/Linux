#include "func.h"
int main()
{
	long i=100;
	printf("I am printf i=%d\n",i);
}
