#include <stdio.h>
int add(int,int);
int main()
{
	int result=add(3,4);
	printf("result=%d\n",result);
	return 0;
}
