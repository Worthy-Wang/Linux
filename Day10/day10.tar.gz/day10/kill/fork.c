#include <func.h>

int main()
{
	if(!fork())
	{
		while(1);
	}else{
		while(1);
	}
}
